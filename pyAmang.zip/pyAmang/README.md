
### Installing

``` bash
pip3 install pyrogram
```
